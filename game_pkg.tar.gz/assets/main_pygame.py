import asyncio
from ui.pygame_gui import PyGameUI

async def main():
    app = PyGameUI()
    await app.run()

if __name__ == "__main__":
    asyncio.run(main())

